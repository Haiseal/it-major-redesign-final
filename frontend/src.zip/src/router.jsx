import { createBrowserRouter, Navigate } from 'react-router-dom'
import HomePage from './pages/HomePage'
import LoginPage from './pages/LoginPage'
import RegisterPage from './pages/RegisterPage'
import UnauthorizedPage from './pages/UnauthorizedPage'
import RoleHomePage from './pages/RoleHomePage'
import StudentProfilePage from './pages/StudentProfilePage'
import StudentDashboardPage from './pages/StudentDashboardPage'
import StudentAssessmentPage from './pages/StudentAssessmentPage'
import RecommendationResultPage from './pages/RecommendationResultPage'
import StudentHistoryPage from './pages/StudentHistoryPage'
import AdvisorDashboardPage from './pages/AdvisorDashboardPage'
import AdvisorStudentsPage from './pages/AdvisorStudentsPage'
import AdvisorRunDetailPage from './pages/AdvisorRunDetailPage'
import DepartmentDashboardPage from './pages/DepartmentDashboardPage'
import DepartmentMajorsPage from './pages/DepartmentMajorsPage'
import DepartmentSubjectsPage from './pages/DepartmentSubjectsPage'
import DepartmentLearningPathsPage from './pages/DepartmentLearningPathsPage'
import DepartmentWeightsPage from './pages/DepartmentWeightsPage'
import SystemDashboardPage from './pages/SystemDashboardPage'
import SystemUsersPage from './pages/SystemUsersPage'
import AuthLayout from './layouts/AuthLayout'
import DashboardLayout from './layouts/DashboardLayout'
import ProtectedRoute from './components/ProtectedRoute'

export const router = createBrowserRouter([
  { path: '/', element: <HomePage /> },
  {
    element: <AuthLayout />,
    children: [
      { path: '/login', element: <LoginPage /> },
      { path: '/register', element: <RegisterPage /> },
      { path: '/unauthorized', element: <UnauthorizedPage /> },
    ],
  },
  {
    element: <DashboardLayout />,
    children: [
      { path: '/student/home', element: <ProtectedRoute roles={['student']}><RoleHomePage role="student" /></ProtectedRoute> },
      { path: '/student/dashboard', element: <ProtectedRoute roles={['student']}><StudentDashboardPage /></ProtectedRoute> },
      { path: '/student/assessment', element: <ProtectedRoute roles={['student']}><StudentAssessmentPage /></ProtectedRoute> },
      { path: '/student/history', element: <ProtectedRoute roles={['student']}><StudentHistoryPage /></ProtectedRoute> },
      { path: '/student/result/:runId', element: <ProtectedRoute roles={['student']}><RecommendationResultPage /></ProtectedRoute> },
      { path: '/student/profile', element: <ProtectedRoute roles={['student']}><StudentProfilePage /></ProtectedRoute> },

      { path: '/advisor/home', element: <ProtectedRoute roles={['advisor']}><RoleHomePage role="advisor" /></ProtectedRoute> },
      { path: '/advisor/dashboard', element: <ProtectedRoute roles={['advisor']}><AdvisorDashboardPage /></ProtectedRoute> },
      { path: '/advisor/students', element: <ProtectedRoute roles={['advisor']}><AdvisorStudentsPage /></ProtectedRoute> },
      { path: '/advisor/run/:runId', element: <ProtectedRoute roles={['advisor']}><AdvisorRunDetailPage /></ProtectedRoute> },

      { path: '/department/home', element: <ProtectedRoute roles={['department_admin']}><RoleHomePage role="department_admin" /></ProtectedRoute> },
      { path: '/department/dashboard', element: <ProtectedRoute roles={['department_admin']}><DepartmentDashboardPage /></ProtectedRoute> },
      { path: '/department/majors', element: <ProtectedRoute roles={['department_admin']}><DepartmentMajorsPage /></ProtectedRoute> },
      { path: '/department/subjects', element: <ProtectedRoute roles={['department_admin']}><DepartmentSubjectsPage /></ProtectedRoute> },
      { path: '/department/learning-paths', element: <ProtectedRoute roles={['department_admin']}><DepartmentLearningPathsPage /></ProtectedRoute> },
      { path: '/department/weights', element: <ProtectedRoute roles={['department_admin']}><DepartmentWeightsPage /></ProtectedRoute> },

      { path: '/system/home', element: <ProtectedRoute roles={['system_admin']}><RoleHomePage role="system_admin" /></ProtectedRoute> },
      { path: '/system/dashboard', element: <ProtectedRoute roles={['system_admin']}><SystemDashboardPage /></ProtectedRoute> },
      { path: '/system/users', element: <ProtectedRoute roles={['system_admin']}><SystemUsersPage /></ProtectedRoute> },
    ],
  },
  { path: '*', element: <Navigate to='/' replace /> },
])
