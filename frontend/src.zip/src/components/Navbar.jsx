import { Link, NavLink } from 'react-router-dom'
import { useAuth } from '../contexts/AuthContext'

function itemClass({ isActive }) {
  return isActive ? 'nav-link nav-link-active' : 'nav-link'
}

export default function Navbar() {
  const { user, logout } = useAuth()

  return (
    <header className="navbar">
      <div className="navbar-inner">
        <div>
          <p className="eyebrow">Academic Decision Support System</p>
          <Link to="/" className="brand-title">IT Major Recommendation System</Link>
        </div>

        <nav className="nav-links">
          <NavLink to="/" className={itemClass}>Home</NavLink>
          {user?.role === 'student' && <>
            <NavLink to="/student" className={itemClass}>Student</NavLink>
            <NavLink to="/student/profile" className={itemClass}>Profile</NavLink>
          </>}
          {user?.role === 'advisor' && <NavLink to="/advisor" className={itemClass}>Advisor</NavLink>}
          {user?.role === 'department_admin' && <NavLink to="/department-admin" className={itemClass}>Department</NavLink>}
          {user?.role === 'system_admin' && <NavLink to="/system-admin" className={itemClass}>System</NavLink>}
        </nav>

        <div className="hero-actions">
          {user ? (
            <>
              <span className="muted">{user.fullName} · {user.role}</span>
              <button className="button secondary" onClick={logout}>Logout</button>
            </>
          ) : (
            <>
              <NavLink to="/register" className="button secondary">Register</NavLink>
              <NavLink to="/login" className="button primary">Login</NavLink>
            </>
          )}
        </div>
      </div>
    </header>
  )
}
