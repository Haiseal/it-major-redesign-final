import { useEffect, useState } from 'react'
import PageHeader from '../components/PageHeader'
import LoadingState from '../components/LoadingState'
import { createSubjectApi, deleteSubjectApi, getSubjectsApi, updateSubjectApi } from '../api/departmentAdminApi'

const emptyForm = { subjectCode: '', name: '', category: 'core', isUsedInAlgorithm: true }

export default function DepartmentSubjectsPage() {
  const [rows, setRows] = useState(null)
  const [form, setForm] = useState(emptyForm)
  const [editingId, setEditingId] = useState(null)

  const load = () => getSubjectsApi().then((res) => setRows(res.data))
  useEffect(() => { load() }, [])
  if (!rows) return <LoadingState text="Loading subjects..." />

  const submit = async (e) => {
    e.preventDefault()
    if (editingId) await updateSubjectApi(editingId, form)
    else await createSubjectApi(form)
    setForm(emptyForm)
    setEditingId(null)
    load()
  }

  return (
    <div className="stack-lg">
      <PageHeader title="Subject Management" subtitle="Maintain subjects and toggle whether they are used in the algorithm." />
      <form className="card form-card" onSubmit={submit}>
        <div className="form-grid four">
          <input placeholder="Code" value={form.subjectCode} onChange={(e) => setForm({ ...form, subjectCode: e.target.value })} />
          <input placeholder="Name" value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          <select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}>
            <option value="core">Core</option>
            <option value="optional">Optional</option>
            <option value="general">General</option>
          </select>
          <label className="checkbox-row"><input type="checkbox" checked={form.isUsedInAlgorithm} onChange={(e) => setForm({ ...form, isUsedInAlgorithm: e.target.checked })} /> Used in algorithm</label>
        </div>
        <div className="page-actions">
          <button className="button secondary" type="button" onClick={() => { setForm(emptyForm); setEditingId(null) }}>Clear</button>
          <button className="button primary">{editingId ? 'Update Subject' : 'Add Subject'}</button>
        </div>
      </form>
      <div className="card table-card">
        <table>
          <thead><tr><th>Code</th><th>Name</th><th>Category</th><th>Used</th><th /></tr></thead>
          <tbody>
            {rows.map((row) => (
              <tr key={row.id}>
                <td>{row.subject_code}</td><td>{row.name}</td><td>{row.category}</td><td>{row.is_used_in_algorithm ? 'On' : 'Off'}</td>
                <td>
                  <div className="page-actions compact-actions">
                    <button className="button secondary small" onClick={() => { setEditingId(row.id); setForm({ subjectCode: row.subject_code, name: row.name, category: row.category, isUsedInAlgorithm: !!row.is_used_in_algorithm }) }}>Edit</button>
                    <button className="button secondary small" onClick={() => { deleteSubjectApi(row.id).then(load) }}>Delete</button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
