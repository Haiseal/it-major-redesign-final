import { useEffect, useMemo, useState } from 'react'
import { useNavigate } from 'react-router-dom'
import PageHeader from '../components/PageHeader'
import LoadingState from '../components/LoadingState'
import { getFormOptionsApi, generateRecommendation } from '../api/recommendationApi'

const DRAFT_KEY = 'student-assessment-draft'

export default function StudentAssessmentPage() {
  const navigate = useNavigate()
  const [options, setOptions] = useState(null)
  const [submitting, setSubmitting] = useState(false)
  const [subjectScores, setSubjectScores] = useState({})
  const [interests, setInterests] = useState({})
  const [selfAssessments, setSelfAssessments] = useState({})

  useEffect(() => {
    getFormOptionsApi().then((res) => {
      setOptions(res.data)
      const saved = JSON.parse(localStorage.getItem(DRAFT_KEY) || 'null')
      if (saved) {
        setSubjectScores(saved.subjectScores || {})
        setInterests(saved.interests || {})
        setSelfAssessments(saved.selfAssessments || {})
      } else {
        const interestInit = {}
        const selfInit = {}
        res.data.interests.forEach((item) => { interestInit[item.name] = 3 })
        res.data.questions.forEach((item) => { selfInit[item.question_text] = 3 })
        setInterests(interestInit)
        setSelfAssessments(selfInit)
      }
    })
  }, [])

  const algorithmSubjects = useMemo(() => options?.subjects?.filter((item) => item.is_used_in_algorithm) || [], [options])

  const saveDraft = () => {
    localStorage.setItem(DRAFT_KEY, JSON.stringify({ subjectScores, interests, selfAssessments }))
    alert('Draft saved locally.')
  }

  const handleSubmit = async () => {
    setSubmitting(true)
    try {
      const payload = { subjectScores, interests, selfAssessments }
      const { data } = await generateRecommendation(payload)
      localStorage.removeItem(DRAFT_KEY)
      navigate(`/student/result/${data.runId}`)
    } catch (error) {
      alert(error.response?.data?.message || 'Failed to generate recommendation.')
    } finally {
      setSubmitting(false)
    }
  }

  if (!options) return <LoadingState text="Loading assessment form..." />

  return (
    <div className="stack-lg">
      <PageHeader title="New Assessment" subtitle="Complete the three sections below, then generate your recommendation." />

      <div className="card">
        <h3>Section 1 — Subject Scores</h3>
        <div className="form-grid two">
          {algorithmSubjects.map((subject) => (
            <div key={subject.id} className="field-row compact">
              <span>{subject.name}</span>
              <input type="number" min="0" max="10" step="0.1" value={subjectScores[subject.name] ?? ''} onChange={(e) => setSubjectScores({ ...subjectScores, [subject.name]: e.target.value })} />
            </div>
          ))}
        </div>
      </div>

      <div className="card">
        <h3>Section 2 — Interests</h3>
        <div className="stack-md">
          {options.interests.map((item) => (
            <div key={item.id} className="slider-row">
              <label>{item.name}</label>
              <input type="range" min="1" max="5" value={interests[item.name] ?? 3} onChange={(e) => setInterests({ ...interests, [item.name]: Number(e.target.value) })} />
              <strong>{interests[item.name] ?? 3}</strong>
            </div>
          ))}
        </div>
      </div>

      <div className="card">
        <h3>Section 3 — Self-assessment</h3>
        <div className="stack-md">
          {options.questions.map((item) => (
            <div key={item.id} className="rating-row">
              <span>{item.question_text}</span>
              <div className="rating-group">
                {[1, 2, 3, 4, 5].map((value) => (
                  <button key={value} type="button" className={selfAssessments[item.question_text] === value ? 'rating-pill active' : 'rating-pill'} onClick={() => setSelfAssessments({ ...selfAssessments, [item.question_text]: value })}>{value}</button>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>

      <div className="bottom-actions">
        <button className="button secondary" onClick={() => navigate('/student/dashboard')}>Cancel</button>
        <button className="button secondary" onClick={saveDraft}>Save Draft</button>
        <button className="button primary" onClick={handleSubmit} disabled={submitting}>{submitting ? 'Generating...' : 'Generate Recommendation'}</button>
      </div>
    </div>
  )
}
