import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { getSystemDashboardApi } from '../api/systemAdminApi'
import PageHeader from '../components/PageHeader'
import StatCard from '../components/StatCard'
import LoadingState from '../components/LoadingState'

export default function SystemDashboardPage() {
  const [data, setData] = useState(null)
  useEffect(() => { getSystemDashboardApi().then((res) => setData(res.data)) }, [])
  if (!data) return <LoadingState text="Loading system dashboard..." />

  return (
    <div className="stack-lg">
      <PageHeader title="System Dashboard" subtitle="Platform-level user administration overview." actions={<Link className="button primary" to="/system/users">Manage Users</Link>} />
      <div className="stats-grid two">
        <StatCard label="Total users" value={data.totalUsers} />
        <div className="card">
          <h3>Users by role</h3>
          <div className="stack-sm">
            {data.usersByRole.map((item) => <div key={item.role} className="simple-row"><span>{item.role}</span><strong>{item.total}</strong></div>)}
          </div>
        </div>
      </div>
    </div>
  )
}
