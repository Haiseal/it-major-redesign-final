import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { getDepartmentDashboardApi } from '../api/departmentAdminApi'
import PageHeader from '../components/PageHeader'
import StatCard from '../components/StatCard'
import LoadingState from '../components/LoadingState'

export default function DepartmentDashboardPage() {
  const [data, setData] = useState(null)
  useEffect(() => { getDepartmentDashboardApi().then((res) => setData(res.data)) }, [])
  if (!data) return <LoadingState text="Loading department dashboard..." />

  return (
    <div className="stack-lg">
      <PageHeader title="Department Dashboard" subtitle="Manage academic data and recommendation configuration." />
      <div className="stats-grid three">
        <StatCard label="Total majors" value={data.totalMajors} />
        <StatCard label="Total subjects" value={data.totalSubjects} />
        <StatCard label="Learning paths" value={data.totalLearningPaths} />
      </div>
      <div className="page-actions">
        <Link className="button secondary" to="/department/majors">Majors</Link>
        <Link className="button secondary" to="/department/subjects">Subjects</Link>
        <Link className="button secondary" to="/department/learning-paths">Learning Paths</Link>
        <Link className="button secondary" to="/department/weights">Weights</Link>
      </div>
    </div>
  )
}
