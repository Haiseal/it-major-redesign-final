import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { getAdvisorStudentsApi } from '../api/advisorApi'
import PageHeader from '../components/PageHeader'
import LoadingState from '../components/LoadingState'

export default function AdvisorStudentsPage() {
  const [rows, setRows] = useState(null)
  useEffect(() => { getAdvisorStudentsApi().then((res) => setRows(res.data)) }, [])
  if (!rows) return <LoadingState text="Loading student list..." />

  return (
    <div className="stack-lg">
      <PageHeader title="Student Assessments" subtitle="Review submitted recommendation runs and add advisor notes." />
      <div className="card table-card">
        <table>
          <thead><tr><th>Student</th><th>Date</th><th>Top major</th><th>Status</th><th>Confidence</th><th /></tr></thead>
          <tbody>
            {rows.map((row) => (
              <tr key={row.id}>
                <td>{row.student_name}</td>
                <td>{new Date(row.created_at).toLocaleDateString()}</td>
                <td>{row.top_major_name || 'N/A'}</td>
                <td>{row.review_status}</td>
                <td>{row.confidence_level || 'N/A'}</td>
                <td><Link className="button secondary small" to={`/advisor/run/${row.id}`}>View</Link></td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
