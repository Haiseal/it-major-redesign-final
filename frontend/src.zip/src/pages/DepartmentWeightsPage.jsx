import { useEffect, useState } from 'react'
import PageHeader from '../components/PageHeader'
import LoadingState from '../components/LoadingState'
import { getMajorsApi, getWeightsByMajorApi, updateWeightApi } from '../api/departmentAdminApi'

export default function DepartmentWeightsPage() {
  const [majors, setMajors] = useState(null)
  const [majorId, setMajorId] = useState('')
  const [tab, setTab] = useState('foundation')
  const [weights, setWeights] = useState(null)

  useEffect(() => {
    getMajorsApi().then((res) => {
      setMajors(res.data)
      if (res.data[0]) setMajorId(String(res.data[0].id))
    })
  }, [])

  useEffect(() => {
    if (majorId) getWeightsByMajorApi(majorId).then((res) => setWeights(res.data))
  }, [majorId])

  if (!majors || !weights) return <LoadingState text="Loading weights..." />

  const rows = tab === 'foundation' ? weights.foundation : tab === 'interests' ? weights.interests : weights.selfAssessments

  const save = async (type, id, value) => {
    await updateWeightApi(type, id, { weight: Number(value) })
    const { data } = await getWeightsByMajorApi(majorId)
    setWeights(data)
  }

  return (
    <div className="stack-lg">
      <PageHeader title="Weight Management" subtitle="Edit academic, interest, and self-assessment weights by major." />
      <div className="card form-card">
        <div className="page-actions">
          <select value={majorId} onChange={(e) => setMajorId(e.target.value)}>
            {majors.map((major) => <option key={major.id} value={major.id}>{major.name}</option>)}
          </select>
          <button className={tab === 'foundation' ? 'button primary' : 'button secondary'} onClick={() => setTab('foundation')}>Academic weights</button>
          <button className={tab === 'interests' ? 'button primary' : 'button secondary'} onClick={() => setTab('interests')}>Interest weights</button>
          <button className={tab === 'selfAssessments' ? 'button primary' : 'button secondary'} onClick={() => setTab('selfAssessments')}>Self-assessment weights</button>
        </div>
      </div>
      <div className="card table-card">
        <table>
          <thead><tr><th>Name</th><th>Weight</th><th /></tr></thead>
          <tbody>
            {rows.map((row) => (
              <WeightRow key={row.id} row={row} type={tab} onSave={save} />
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

function WeightRow({ row, type, onSave }) {
  const [value, setValue] = useState(row.weight)
  return (
    <tr>
      <td>{row.name || row.question_text}</td>
      <td><input type="number" step="0.1" value={value} onChange={(e) => setValue(e.target.value)} /></td>
      <td><button className="button secondary small" onClick={() => onSave(type, row.id, value)}>Save</button></td>
    </tr>
  )
}
