import RecommendationResultPage from './RecommendationResultPage'

export default RecommendationResultPage
