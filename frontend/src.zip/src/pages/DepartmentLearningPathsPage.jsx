import { useEffect, useMemo, useState } from 'react'
import PageHeader from '../components/PageHeader'
import LoadingState from '../components/LoadingState'
import { createLearningPathApi, deleteLearningPathApi, getLearningPathsApi, getMajorsApi, updateLearningPathApi } from '../api/departmentAdminApi'

const emptyForm = { majorId: '', yearLabel: 'Year 2', content: '' }

export default function DepartmentLearningPathsPage() {
  const [majors, setMajors] = useState(null)
  const [paths, setPaths] = useState(null)
  const [selectedMajorId, setSelectedMajorId] = useState('')
  const [form, setForm] = useState(emptyForm)
  const [editingId, setEditingId] = useState(null)

  const load = async () => {
    const [majorRes, pathRes] = await Promise.all([getMajorsApi(), getLearningPathsApi()])
    setMajors(majorRes.data)
    setPaths(pathRes.data)
    if (!selectedMajorId && majorRes.data[0]) {
      setSelectedMajorId(String(majorRes.data[0].id))
      setForm((prev) => ({ ...prev, majorId: String(majorRes.data[0].id) }))
    }
  }

  useEffect(() => { load() }, [])
  const filtered = useMemo(() => (paths || []).filter((item) => String(item.major_id) === String(selectedMajorId)), [paths, selectedMajorId])

  if (!majors || !paths) return <LoadingState text="Loading learning paths..." />

  const submit = async (e) => {
    e.preventDefault()
    const payload = { ...form, majorId: Number(form.majorId || selectedMajorId) }
    if (editingId) await updateLearningPathApi(editingId, { content: payload.content, yearLabel: payload.yearLabel })
    else await createLearningPathApi(payload)
    setEditingId(null)
    setForm({ majorId: selectedMajorId, yearLabel: 'Year 2', content: '' })
    load()
  }

  return (
    <div className="stack-lg">
      <PageHeader title="Learning Path Management" subtitle="Maintain Year 2, Year 3, and Year 4 learning path content by major." />
      <div className="card form-card">
        <label>Select major</label>
        <select value={selectedMajorId} onChange={(e) => { setSelectedMajorId(e.target.value); setForm({ ...form, majorId: e.target.value }) }}>
          {majors.map((major) => <option key={major.id} value={major.id}>{major.name}</option>)}
        </select>
      </div>
      <form className="card form-card" onSubmit={submit}>
        <div className="form-grid three">
          <select value={form.majorId || selectedMajorId} onChange={(e) => setForm({ ...form, majorId: e.target.value })}>
            {majors.map((major) => <option key={major.id} value={major.id}>{major.name}</option>)}
          </select>
          <select value={form.yearLabel} onChange={(e) => setForm({ ...form, yearLabel: e.target.value })}>
            <option>Year 2</option><option>Year 3</option><option>Year 4</option>
          </select>
          <input placeholder="Learning path content" value={form.content} onChange={(e) => setForm({ ...form, content: e.target.value })} />
        </div>
        <div className="page-actions">
          <button className="button secondary" type="button" onClick={() => { setEditingId(null); setForm({ majorId: selectedMajorId, yearLabel: 'Year 2', content: '' }) }}>Clear</button>
          <button className="button primary">{editingId ? 'Update Path' : 'Add Path'}</button>
        </div>
      </form>
      <div className="card table-card">
        <table>
          <thead><tr><th>Year</th><th>Content</th><th /></tr></thead>
          <tbody>
            {filtered.map((row) => (
              <tr key={row.id}>
                <td>{row.year_label}</td><td>{row.content}</td>
                <td>
                  <div className="page-actions compact-actions">
                    <button className="button secondary small" onClick={() => { setEditingId(row.id); setForm({ majorId: String(row.major_id), yearLabel: row.year_label, content: row.content }) }}>Edit</button>
                    <button className="button secondary small" onClick={() => { deleteLearningPathApi(row.id).then(load) }}>Delete</button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  )
}
