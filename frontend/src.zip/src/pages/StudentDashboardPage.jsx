import { Link } from 'react-router-dom'
import { useEffect, useState } from 'react'
import { getStudentDashboardApi } from '../api/studentApi'
import PageHeader from '../components/PageHeader'
import StatCard from '../components/StatCard'
import LoadingState from '../components/LoadingState'
import { useAuth } from '../contexts/AuthContext'

export default function StudentDashboardPage() {
  const { user } = useAuth()
  const [data, setData] = useState(null)

  useEffect(() => {
    getStudentDashboardApi().then((res) => setData(res.data)).catch(() => setData({ totalAssessments: 0 }))
  }, [])

  if (!data) return <LoadingState text="Loading student dashboard..." />

  return (
    <div className="stack-lg">
      <PageHeader
        title={`Hello ${user?.fullName || 'Student'} 👋`}
        subtitle="Welcome to your student dashboard. Start a new assessment or review previous recommendations."
        actions={<Link className="button primary" to="/student/assessment">Start Assessment</Link>}
      />

      <div className="stats-grid three">
        <StatCard label="Latest recommendation" value={data.latestRecommendation?.top_major_name || 'No result yet'} helper={data.latestRecommendation ? `${data.latestRecommendation.level} confidence` : 'Run your first assessment'} />
        <StatCard label="Advisor feedback" value={data.latestFeedback?.advisor_name || 'No feedback yet'} helper={data.latestFeedback?.note_text || 'No advisor note available'} />
        <StatCard label="Total assessments" value={data.totalAssessments || 0} helper="Historical recommendation runs" />
      </div>

      <div className="stats-grid two">
        <div className="card quick-card">
          <h3>Latest recommendation</h3>
          {data.latestRecommendation ? (
            <>
              <p><strong>{data.latestRecommendation.top_major_name}</strong></p>
              <p>{new Date(data.latestRecommendation.created_at).toLocaleString()}</p>
              <Link className="button secondary" to={`/student/result/${data.latestRecommendation.id}`}>View result</Link>
            </>
          ) : <p>No recommendation has been generated yet.</p>}
        </div>

        <div className="card quick-card">
          <h3>Quick links</h3>
          <div className="stack-sm">
            <Link className="button secondary" to="/student/assessment">New assessment</Link>
            <Link className="button secondary" to="/student/history">Assessment history</Link>
          </div>
        </div>
      </div>
    </div>
  )
}
