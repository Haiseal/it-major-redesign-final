export function getDefaultRouteByRole(role) {
  switch (role) {
    case 'student':
      return '/student/home'
    case 'advisor':
      return '/advisor/home'
    case 'department_admin':
      return '/department/home'
    case 'system_admin':
      return '/system/home'
    default:
      return '/login'
  }
}

export const sidebarByRole = {
  student: [
    { label: 'Home', to: '/student/home' },
    { label: 'Dashboard', to: '/student/dashboard' },
    { label: 'Assessment', to: '/student/assessment' },
    { label: 'History', to: '/student/history' },
    { label: 'Profile', to: '/student/profile' },
  ],
  advisor: [
    { label: 'Home', to: '/advisor/home' },
    { label: 'Dashboard', to: '/advisor/dashboard' },
    { label: 'Students', to: '/advisor/students' },
  ],
  department_admin: [
    { label: 'Home', to: '/department/home' },
    { label: 'Dashboard', to: '/department/dashboard' },
    { label: 'Majors', to: '/department/majors' },
    { label: 'Subjects', to: '/department/subjects' },
    { label: 'Learning Paths', to: '/department/learning-paths' },
    { label: 'Weights', to: '/department/weights' },
  ],
  system_admin: [
    { label: 'Home', to: '/system/home' },
    { label: 'Dashboard', to: '/system/dashboard' },
    { label: 'Users', to: '/system/users' },
  ],
}
